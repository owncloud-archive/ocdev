{% include 'licenses/licenses.php' %}

angular.module('{{ app.namespace }}', ['ngMock']);