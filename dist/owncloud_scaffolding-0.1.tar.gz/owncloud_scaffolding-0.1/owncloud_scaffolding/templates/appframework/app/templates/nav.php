<li class="open">
	<a href="#" class="title">Level 1</a>
	<ul>
		<li>
			<a href="#" class="title">Level 2</a>
		</li>
	</ul>
</li>
