from os.path import realpath, dirname, join

TEMPLATE_DIRECTORY = join(dirname(realpath(__file__)), 'templates/')